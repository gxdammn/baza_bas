from django import forms


class UserForm(forms.Form):
    name = forms.CharField(label='Имя') #max_length=100)
    weight = forms.IntegerField(label='Вес')
    takeoff_speed = forms.IntegerField(label='Имя')
    decline_speed = forms.IntegerField(label='Макс скорость набора высоты')
    max_speed = forms.IntegerField(label='Макс скорость')
    max_height = forms.IntegerField(label='Имя')
    max_time = forms.IntegerField(label='Макс время полёта')
    mode_gps = forms.CharField(label='Режим GPS')
    picture = forms.URLField(label='Прямая ссылка на картинку')
