from django.shortcuts import render
from django.http import HttpResponse
from .forms import UserForm
import pymysql


def index(request):
    connection = pymysql.connect(  # инициируем ссесию подключения к БД
        host="localhost",
        user="root",
        password="root",
        database="bot"
    )
    with connection.cursor() as cursor:  # из текущей сессии забираем значение кода ошибки
        cursor.execute('SELECT * FROM baza_bas.main_tablica')
        otvet = (cursor.fetchall())  # полученное из бд подобие массива превращаем в строку
        connection.close()  # закрываем ссесию
    return render(request, 'test.html', context={'data':otvet})

def input_form(request):
    if request.method == "POST":
        name = request.POST.get("name")
        weight = request.POST.get("weight")
        takeoff_speed = request.POST.get("takeoff_speed")
        decline_speed = request.POST.get("decline_speed")
        max_speed = request.POST.get("max_speed")
        max_height = request.POST.get("max_height")
        max_time = request.POST.get("max_time")
        mode_gps = request.POST.get("mode_gps")
        picture = request.POST.get("picture")
        print(file)
        connection = pymysql.connect(  # инициируем ссесию подключения к БД
            host="localhost",
            user="root",
            password="root",
            database="bot"
        )
        with connection.cursor() as cursor:  # из текущей сессии забираем значение кода ошибки
            #INSERT INTO baza_bas.main_tablica (name, weight, takeoff_speed, decline_speed, max_speed, max_height, max_time, mode_gps) VALUES ('test', 1, 1, 1, 1, 1, 1, 'устал играть роли');
            #INSERT INTO baza_bas.main_tablica (name, weight, takeoff_speed, ' 'decline_speed, max_speed, max_height, max_time, mode_gps) VALUES ' '(test,2,2,2,2,2,2,2,устал играть роли)'
            str_sql ="INSERT INTO baza_bas.main_tablica (name, weight, takeoff_speed, decline_speed, max_speed, max_height, max_time, mode_gps, image) VALUES ('" + str(name) + "', " + str(weight) + ', ' + str(takeoff_speed) + ', ' + str(decline_speed) + ', ' + str(max_speed) + ', ' + str(max_height) + ', ' + str(max_time) + ", '" + str(mode_gps) + ", '"  +  str(picture) + "')"
            cursor.execute(str_sql)
            connection.commit()
            connection.close()  # закрываем ссесию
        return render(request, 'form1.html', {"name": name, "weight": weight, "takeoff_speed": takeoff_speed, "decline_speed": decline_speed, "max_speed": max_speed, "max_height": max_height, "max_time": max_time, "mode_gps":mode_gps, "file":file})
        #return HttpResponse(f"<h2>Cработало</h2>")
    else:
        userform = UserForm()
        return render(request, 'form.html', {"form": userform})
    # return render(request, 'form.html')


# Create your views here.
